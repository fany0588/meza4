from django.db import models
from django.utils import timezone
from django.contrib.auth.models import AbstractUser

# ==========================================
# MODELO: USUARIO (solo login)
# ==========================================
class Usuario(AbstractUser):
    # No agregamos más campos, solo el usuario estándar
    pass

    def __str__(self):
        return self.username

# ==========================================
# MODELO: CLIENTE (datos personales reales)
# ==========================================
from django.contrib.auth.hashers import make_password, check_password

class Cliente(models.Model):
    id_cliente = models.AutoField(primary_key=True, blank=True)  # Primary key personalizada
    usuario = models.OneToOneField(Usuario, on_delete=models.CASCADE, null=True, blank=True)
    email = models.EmailField(max_length=254, blank=True)
    nombre = models.CharField(max_length=150)
    apellido = models.CharField(max_length=150, blank=True)
    contraseña = models.CharField(max_length=128, blank=True)
    telefono = models.CharField(max_length=50, blank=True)
    calle = models.CharField(max_length=200, blank=True)
    numero_casa = models.CharField(max_length=50, blank=True)
    colonia = models.CharField(max_length=100, blank=True)
    ciudad = models.CharField(max_length=100, blank=True)
    codigo_postal = models.CharField(max_length=20, blank=True)
    descripcion_direccion = models.TextField(blank=True)
    metodo_pago = models.CharField(max_length=50, blank=True)
    fecha_registro = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

    def set_password(self, raw_password):
        """Encripta y guarda la contraseña"""
        self.contraseña = make_password(raw_password)
        self.save()

    def check_password(self, raw_password):
        """Verifica si la contraseña es correcta"""
        return check_password(raw_password, self.contraseña)
# ==========================================
# MODELOS DE PRODUCTOS
# ==========================================
class Mujer(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre_producto = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    talla = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    material = models.CharField(max_length=100, blank=True)
    imagen = models.ImageField(upload_to='productos/mujer/', blank=True, null=True)
    temporada = models.CharField(max_length=20, choices=[('verano', 'Verano'), ('invierno', 'Invierno')])
    tipo = models.CharField(max_length=100)

    def __str__(self):
        return self.nombre_producto


class Hombre(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre_producto = models.CharField(max_length=200)
    descripcion = models.TextField(blank=True)
    talla = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    material = models.CharField(max_length=100, blank=True)
    imagen = models.ImageField(upload_to='productos/hombre/', blank=True, null=True)
    tipo = models.CharField(max_length=100)
    temporada = models.CharField(max_length=20, choices=[('verano', 'Verano'), ('invierno', 'Invierno')])

    def __str__(self):
        return self.nombre_producto


class Ninas(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre_producto = models.CharField(max_length=200)
    tipo = models.CharField(max_length=100)
    talla = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    descripcion = models.TextField(blank=True)
    material = models.CharField(max_length=100, blank=True)
    temporada = models.CharField(max_length=20, choices=[('verano', 'Verano'), ('invierno', 'Invierno')])
    edad_recomendada = models.CharField(max_length=50, blank=True)
    imagen = models.ImageField(upload_to='productos/ninas/', blank=True, null=True)

    def __str__(self):
        return self.nombre_producto


class Ninos(models.Model):
    id_producto = models.AutoField(primary_key=True)
    nombre_producto = models.CharField(max_length=200)
    tipo = models.CharField(max_length=100)
    talla = models.CharField(max_length=50)
    color = models.CharField(max_length=50)
    precio = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    descripcion = models.TextField(blank=True)
    material = models.CharField(max_length=100, blank=True)
    temporada = models.CharField(max_length=20, choices=[('verano', 'Verano'), ('invierno', 'Invierno')])
    edad_recomendada = models.CharField(max_length=50, blank=True)
    imagen = models.ImageField(upload_to='productos/ninos/', blank=True, null=True)

    def __str__(self):
        return self.nombre_producto


# ==========================================
# MODELO: CARRITO
# ==========================================
class Carrito(models.Model):
    id_carrito = models.AutoField(primary_key=True)
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    fecha_creacion = models.DateTimeField(default=timezone.now)
    activo = models.BooleanField(default=True)

    def __str__(self):
        return f"Carrito {self.id_carrito} - {self.usuario}"


# ==========================================
# MODELO: ITEM DE CARRITO
# ==========================================
class ItemCarrito(models.Model):
    id_item = models.AutoField(primary_key=True)
    carrito = models.ForeignKey(Carrito, on_delete=models.CASCADE)
    
    producto_mujer = models.ForeignKey(Mujer, on_delete=models.CASCADE, null=True, blank=True)
    producto_hombre = models.ForeignKey(Hombre, on_delete=models.CASCADE, null=True, blank=True)
    producto_ninas = models.ForeignKey(Ninas, on_delete=models.CASCADE, null=True, blank=True)
    producto_ninos = models.ForeignKey(Ninos, on_delete=models.CASCADE, null=True, blank=True)

    cantidad = models.PositiveIntegerField(default=1)
    fecha_agregado = models.DateTimeField(default=timezone.now)

    def get_producto(self):
        if self.producto_mujer: return self.producto_mujer
        if self.producto_hombre: return self.producto_hombre
        if self.producto_ninas: return self.producto_ninas
        if self.producto_ninos: return self.producto_ninos
        return None

    def get_precio_total(self):
        producto = self.get_producto()
        if producto:
            return producto.precio * self.cantidad
        return 0

    def __str__(self):
        return f"Item {self.id_item}"


# ==========================================
# MODELO: FAVORITO
# ==========================================
class Favorito(models.Model):
    id_favorito = models.AutoField(primary_key=True)
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)

    producto_mujer = models.ForeignKey(Mujer, on_delete=models.CASCADE, null=True, blank=True)
    producto_hombre = models.ForeignKey(Hombre, on_delete=models.CASCADE, null=True, blank=True)
    producto_ninas = models.ForeignKey(Ninas, on_delete=models.CASCADE, null=True, blank=True)
    producto_ninos = models.ForeignKey(Ninos, on_delete=models.CASCADE, null=True, blank=True)

    fecha_agregado = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"Favorito {self.id_favorito}"
# ==========================================
# MODELO: PEDIDOS
# ==========================================

class Pedido(models.Model):
    id_pedido = models.AutoField(primary_key=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.SET_NULL, null=True, to_field='id_cliente')
    
    producto_mujer = models.ForeignKey(Mujer, on_delete=models.SET_NULL, null=True, blank=True)
    producto_hombre = models.ForeignKey(Hombre, on_delete=models.SET_NULL, null=True, blank=True)
    producto_ninas = models.ForeignKey(Ninas, on_delete=models.SET_NULL, null=True, blank=True)
    producto_ninos = models.ForeignKey(Ninos, on_delete=models.SET_NULL, null=True, blank=True)

    nombre_producto = models.CharField(max_length=200)
    cantidad = models.PositiveIntegerField()
    precio_unitario = models.DecimalField(max_digits=10, decimal_places=2)
    total = models.DecimalField(max_digits=12, decimal_places=2)
    fecha_pedido = models.DateTimeField(default=timezone.now)
    metodo_pago = models.CharField(max_length=50)
    estado = models.CharField(max_length=50, default='pendiente')
    direccion = models.TextField(blank=True)

    def __str__(self):
        return f"Pedido {self.id_pedido}"
    

# ==========================================
# MODELO: RESEÑA
# ==========================================
class Reseña(models.Model):
    id_reseña = models.AutoField(primary_key=True)
    usuario = models.ForeignKey(Usuario, on_delete=models.SET_NULL, null=True)

    producto_mujer = models.ForeignKey(Mujer, on_delete=models.SET_NULL, null=True, blank=True)
    producto_hombre = models.ForeignKey(Hombre, on_delete=models.SET_NULL, null=True, blank=True)
    producto_ninas = models.ForeignKey(Ninas, on_delete=models.SET_NULL, null=True, blank=True)
    producto_ninos = models.ForeignKey(Ninos, on_delete=models.SET_NULL, null=True, blank=True)

    calificacion = models.PositiveSmallIntegerField()
    comentario = models.TextField(blank=True)
    fecha = models.DateTimeField(default=timezone.now)
    foto_producto = models.ImageField(upload_to='reseñas/', blank=True, null=True)

    def __str__(self):
        return f"Reseña {self.id_reseña}"
