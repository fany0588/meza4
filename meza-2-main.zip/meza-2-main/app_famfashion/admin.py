from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import Usuario, Mujer, Hombre, Ninas, Ninos, Pedido, Reseña, Carrito, ItemCarrito, Favorito

@admin.register(Usuario)
class UsuarioAdmin(UserAdmin):
    list_display = ('username', 'first_name', 'last_name')  # QUITAMOS CAMPOS QUE NO EXISTEN
    search_fields = ('username',  'first_name', 'last_name')
    
    fieldsets = UserAdmin.fieldsets + (
        ('Información Adicional', {
            'fields': (
                'telefono', 'calle', 'numero_casa', 'colonia',
                'codigo_postal', 'descripcion_direccion', 'metodo_pago'
            )
        }),
    )


@admin.register(Mujer)
class MujerAdmin(admin.ModelAdmin):
    list_display = ('id_producto', 'nombre_producto', 'tipo', 'talla', 'precio', 'stock')
    list_filter = ('tipo', 'temporada')


@admin.register(Hombre)
class HombreAdmin(admin.ModelAdmin):
    list_display = ('id_producto', 'nombre_producto', 'tipo', 'talla', 'precio', 'stock')
    list_filter = ('tipo', 'temporada')


@admin.register(Ninas)
class NinasAdmin(admin.ModelAdmin):
    list_display = ('id_producto', 'nombre_producto', 'tipo', 'talla', 'precio', 'edad_recomendada')
    list_filter = ('tipo', 'temporada')


@admin.register(Ninos)
class NinosAdmin(admin.ModelAdmin):
    list_display = ('id_producto', 'nombre_producto', 'tipo', 'talla', 'precio', 'edad_recomendada')
    list_filter = ('tipo', 'temporada')


@admin.register(Pedido)
class PedidoAdmin(admin.ModelAdmin):
    # QUITAMOS “usuario” porque NO EXISTE EN TU MODELO
    list_display = ('id_pedido', 'nombre_producto', 'cantidad', 'total', 'estado')
    list_filter = ('estado', 'fecha_pedido')


@admin.register(Reseña)
class ReseñaAdmin(admin.ModelAdmin):
    list_display = ('id_reseña', 'usuario', 'calificacion', 'fecha')
    list_filter = ('calificacion', 'fecha')


@admin.register(Carrito)
class CarritoAdmin(admin.ModelAdmin):
    list_display = ('id_carrito', 'usuario', 'fecha_creacion', 'activo')


@admin.register(ItemCarrito)
class ItemCarritoAdmin(admin.ModelAdmin):
    list_display = ('id_item', 'carrito', 'get_producto_name', 'cantidad')
    
    def get_producto_name(self, obj):
        return obj.get_producto().nombre_producto if obj.get_producto() else "No product"
    get_producto_name.short_description = 'Producto'


@admin.register(Favorito)
class FavoritoAdmin(admin.ModelAdmin):
    list_display = ('id_favorito', 'usuario', 'get_producto_name', 'fecha_agregado')
    
    def get_producto_name(self, obj):
        return obj.get_producto().nombre_producto if obj.get_producto() else "No product"
    get_producto_name.short_description = 'Producto'
